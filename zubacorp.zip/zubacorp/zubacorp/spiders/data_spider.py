# -*- coding: utf-8 -*-
import hashlib
import json
import re
import scrapy
from scrapy.cmdline import execute
from zubacorp.items import ZubacorpItem
from zubacorp import db_config



class DataSpiderSpider(scrapy.Spider):
    name = 'data_spider'
    start_urls = ['https://www.zaubacorp.com/']


    def parse(self, response):
        final_links = db_config.db[db_config.link].find({'Status': 'pending'})

        for detail in final_links:
            link = detail['url']

            headers={
                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'
            }

            yield scrapy.Request(url=link, callback=self.data,
                                 headers=headers,meta={'page_url':link})
    def data(self,response):
        item=ZubacorpItem()

        rows = response.xpath('//table[@class="table table-striped col-md-12 col-sm-12 col-xs-12"]//tr')[1:]
        for row in rows:
            all_td = row.xpath('.//td')
            try:
                CIN=row.xpath('.//td[1]/text()').get()
            except:
                CIN=''
            try:
                Company=row.xpath('.//td[2]/a/text()').get()
            except:
                Company=''
            try:
                url=row.xpath('.//td[2]/a/@href').get()
            except:
                url =''
            try:
                Roc=row.xpath('.//td[3]/text()').get()
            except:
                Roc=''
            try:
                Status=row.xpath('.//td[4]/text()').get()
            except:
                Status=''

            item['CIN']=CIN
            item['Company'] = Company
            item['Roc'] = Roc
            item['Status'] = Status
            item['page_Url'] =response.url
            item['company_url'] = url

            yield item
            print(item)

        try:
            db_config.db[db_config.link].update_one({'url': response.meta['page_url']}, {"$set": {"Status": "done"}})
        except Exception as e:
            print('problem in link update ', str(e))

# execute('''scrapy crawl data_spider'''.split())