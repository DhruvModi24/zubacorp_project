# -*- coding: utf-8 -*-
import hashlib
import scrapy
from scrapy.cmdline import execute
from zubacorp.items import ZubacorplinkItem



class LinkSpiderSpider(scrapy.Spider):
    name = 'link_spider'
    start_urls = ['https://www.zaubacorp.com/']


    def parse(self, response):

        self.headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'
        }
        url='https://www.zaubacorp.com/company-list-company.html'

        yield scrapy.Request(url=url, callback=self.filter_link,
                             headers=self.headers)

    def filter_link(self,response):
        all_links = response.xpath('//div[@id="listContainer"]/ul//li/a/@href').getall()
        for filter_link in all_links:
            yield scrapy.Request(url=filter_link, callback=self.pagination_link,
                                 headers=self.headers)

    def pagination_link(self,response):
        item = ZubacorplinkItem()
        page_count = response.xpath('//span[@style="float:right"]/text()').get().split()[-1].replace(',', '')
        for i in range(1, (int(page_count) + 1)):
            link = response.url.replace('-company.html','/p-'+str(i)+'-company.html')
            item['url'] = link
            item['Status'] = "pending"
            unique = str(link) +  str(i)
            hash_id = int(hashlib.md5(bytes(unique, "utf8")).hexdigest(), 16) % (10 ** 10)
            item['Hash_id'] = str(hash_id)
            print(item)
            yield item

# execute('''scrapy crawl link_spider'''.split())