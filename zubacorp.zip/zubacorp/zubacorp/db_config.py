import pymongo

try:
    conn = pymongo.MongoClient('mongodb://localhost:27017')

    db = conn.zubacorp
    full_data_table = 'zubacorp_data'
    link='zubacorp_link'

except Exception as e:
    print(e)

