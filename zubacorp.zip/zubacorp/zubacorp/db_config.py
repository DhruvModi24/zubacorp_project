import pymongo

try:
    conn = pymongo.MongoClient('mongodb://localhost:27017')

    db = conn.zubacorp
    full_data_table = 'zubacorp_data'
    link='zubacorp_link'

    unique = db[full_data_table].create_index("company_url", unique=True)

except Exception as e:
    print(e)

