# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo
from zubacorp import db_config
from zubacorp.items import *

class ZubacorpPipeline(object):
    insert_count = 0
    def process_item(self, item, spider):

        if isinstance(item, ZubacorplinkItem):

            db_config.db[db_config.link].insert_one(dict(item))

            try:
                self.insert_count += 1
                print("\rData_Count ...%s" % str(self.insert_count), end="")
            except Exception as e:
                print('problem in data insert ', str(e))

            return item

        if isinstance(item, ZubacorpItem):

            db_config.db[db_config.full_data_table].insert_one(dict(item))

            try:
                self.insert_count += 1
                print("\rData_Count ...%s" % str(self.insert_count), end="")
            except Exception as e:
                print('problem in data insert ', str(e))

            return item
